import json
import requests

def lambda_handler(event, context):
    try:
        # FUT.gg API'sinden veri çek
        url = "https://www.fut.gg/api/fut/players/v2/26/?page=3"
        
        # Header'ları ayarla
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Accept-Language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
            'Referer': 'https://www.fut.gg/players/?page=3',
            'Origin': 'https://www.fut.gg'
        }
        
        # API isteği gönder
        response = requests.get(url, headers=headers, timeout=10)
        
        # HTTP durum kodunu kontrol et
        if response.status_code == 200:
            # JSON verisini al
            data = response.json()
            
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': True,
                    'data': data,
                    'message': 'Veri başarıyla alındı'
                })
            }
        else:
            return {
                'statusCode': response.status_code,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': False,
                    'error': f'API hatası: {response.status_code}',
                    'message': 'Veri alınamadı'
                })
            }
            
    except requests.exceptions.RequestException as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': str(e),
                'message': 'Bağlantı hatası oluştu'
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': str(e),
                'message': 'Beklenmeyen hata oluştu'
            })
        }
